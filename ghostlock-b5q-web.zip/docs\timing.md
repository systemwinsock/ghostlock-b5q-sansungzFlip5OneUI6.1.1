# 实测时间数据（SM-F7310 / F7310ZCS5DXJ2 真机，2026-10-24/25）

自动化链：`scripts/fast_root.sh`（重启→70-115s 窗口发射→快速失败→28min/轮→8 轮）。

## 分布

| 场景 | 耗时 | 备注 |
|---|---|---|
| 最好 | 47 秒 | 发射→uid=0（2026-10-24 21:47） |
| 典型 | 3 – 5 分钟 | 好布局 boot 首试即中 |
| 坏布局单轮 | ≤ 28 分钟 | 轮超时后自动重启换布局 |
| 最差完整跑 | 2h54m | 5 连坏布局 + 第 6 轮命中（下表） |

## 最差记录逐轮日志（v12b，2026-10-25）

```
10:57:22 ROUND 1  fired 11:00:58  → 28min 无果
11:29:10 ROUND 2  fired 11:34:18  → 28min 无果
12:02:29 ROUND 3  fired 12:09:00  → 28min 无果
12:37:11 ROUND 4  fired 12:44:46  → 28min 无果
13:12:57 ROUND 5  fired 13:18:01  → 28min 无果
13:46:13 ROUND 6  fired 13:51:11  → ROOT LIVE（本轮 <5 分钟，uid=0 ksu）
```

对比旧配置（EXPLOIT_ATTEMPTS=8 / TIMEOUT=300，未调优）：坏布局单轮 payload
attempt 1 就要烧 40-50 分钟且不自动换布局，最差半天无果。

## 说明

- 慢的本质 = 每 boot 内存布局抽签（mm 碰撞 ≥3 才能过 kernelsnitch 阶段），
  与 PC/USB 无关；同一 exploit 的所有工具（Root-My-Galaxy App、GhostLock-Galaxy
  等）速度特性一致。
- 深阶段（controlled mm group 256 次扫描）不受 `EXPLOIT_ATTEMPT_TIMEOUT_SEC`
  约束，单次 attempt 最长可磨 ~25 分钟，28 分钟轮超时已覆盖。
