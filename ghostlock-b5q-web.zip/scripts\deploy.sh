#!/bin/bash
# ghostlock-b5q 部署脚本：把 payload 三件套与设备端脚本推到手机
# 用法：bash scripts/deploy.sh [adb 路径]（默认 PATH 里的 adb）
set -e
export MSYS_NO_PATHCONV=1
ADB="${1:-adb}"
DIR="$(cd "$(dirname "$0")/.." && pwd)"
DEV=/data/local/tmp/f731

echo "[*] device:"
"$ADB" get-state
"$ADB" shell "mkdir -p $DEV"
"$ADB" push "$DIR/artifacts/b5q-F7310ZCS5DXJ2/cve-2026-43499-app.so" "$DEV/"
"$ADB" push "$DIR/artifacts/b5q-F7310ZCS5DXJ2/cve-2026-43499-root"   "$DEV/"
"$ADB" push "$DIR/artifacts/b5q-F7310ZCS5DXJ2/ksud-s25u-kdp"         /data/local/tmp/
"$ADB" push "$DIR/scripts/root_capture_fast.sh"                      "$DEV/"
"$ADB" shell "chmod 777 $DEV/cve-2026-43499-root /data/local/tmp/ksud-s25u-kdp $DEV/root_capture_fast.sh"
echo "[+] deployed to $DEV (一次部署，长期有效)"
