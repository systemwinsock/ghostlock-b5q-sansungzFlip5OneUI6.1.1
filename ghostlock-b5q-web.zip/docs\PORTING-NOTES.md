# b5q-F7310ZCS5DXJ2 移植笔记

完整流程见上游 [PORTING.md](https://github.com/BuSung-dev/Root-My-Galaxy-Payloads/blob/main/docs/PORTING.md)。
本机（国行 Z Flip5，F7310ZCS5DXJ2，5.15 GKI，RKP/KDP enforcing）要点：

1. 固件提取：boot.img/xbl_config.img → kallsyms → 偏移表（`target.h` /
   `p0_fingerprint.h`，随本仓库提供）。
2. 编译（无需 make，直接调 NDK clang；见上游 Makefile 规则）：
   ```sh
   clang -DAPP_PAYLOAD=1 -DSLIDE_STACK_WRITER=1 -fPIC -O2 -g0 \
     -Isrc -DTARGET_HEADER='"targets/b5q-F7310ZCS5DXJ2/target.h"' \
     src/main.c src/util.c src/slide_app.c src/fops.c src/pipe.c src/root.c src/preload.c \
     -shared -pthread -o build/b5q-F7310ZCS5DXJ2/cve-2026-43499-app.so
   ```
3. **调优**：实机观测 kernelsnitch 碰撞上限 3（wanted=N-1）→ 上游默认
   `S918_KSNITCH_FULL_COLLISIONS 5` 永不可达，改 4 后好布局首试即中。
   这是本仓库相对上游的唯一源码修改（已含在 `target/`）。

## 运行期关键事实（排障用）

- payload 成功后 UMH 拉起 root 守护进程（监听 `/data/local/tmp/temp_su.sock`）；
  **任何 `kill`/重跑循环若 `kill -9` 掉同名进程会杀掉守护进程导致 root 得而复失**
  ——本仓库脚本已保证绝不在中途 kill。
- `--late-load` 必须不带模块路径参数（argc==2），ksud（/data/local/tmp/ksud-s25u-kdp）
  内嵌模块自选。
- exploit 每 boot 仅一次 stack-writer 机会；失败只能重启再试。
- 发射时机：uptime 70–115s（boot 服务风暴后、布局窗口内）。
